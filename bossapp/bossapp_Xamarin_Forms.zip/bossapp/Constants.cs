﻿using System;

namespace bossapp
{
	public static class Constants
	{
		// Replace strings with your mobile services and gateway URLs.
		public static string ApplicationURL = @"https://bossapp.azurewebsites.net";
	}
}

